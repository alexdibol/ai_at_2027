# AIAT From Notebooks to a Governed Assistant — LaTeX Bundle

This bundle contains the complete 40-page manuscript, including:

- the corrected NB00-NB10 tables;
- Appendix A: concrete end-to-end use of the assistant;
- Appendix B: extremely detailed, step-by-step installation of the AIAT Research-to-LEAN Governor in ChatGPT;
- the canonical Project Instructions;
- behavioral acceptance tests;
- troubleshooting, versioning, first-use workflow, and the relationship to the executable Python runtime.

## Compile

Run twice from this directory:

```bash
pdflatex main.tex
pdflatex main.tex
```

The master document is `main.tex` and the manuscript body is `body_styled.tex`.
`appendix_b_chatgpt_installation.tex` is also provided separately for convenient reuse.

## Primary output

`AIAT_From_Notebooks_to_Governed_Assistant.pdf`

## Product-information note

Appendix B reflects OpenAI product documentation checked on September 7, 2026. Product availability and UI labels may change after that date; the appendix cites the relevant OpenAI Help Center pages.
